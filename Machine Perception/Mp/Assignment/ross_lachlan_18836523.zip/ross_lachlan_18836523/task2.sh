#!/bin/sh
python3 twomain.py
